package com.example.irremote;

import android.hardware.ConsumerIrManager;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.tabs.TabLayout;

import java.util.Map;

/**
 * =====================================================================================
 *  MainActivity
 * =====================================================================================
 * هذا هو النشاط الرئيسي للتطبيق. مسؤولياته:
 *  1) التحقق من وجود باعث IR فعلي على الجهاز (hasIrEmitter).
 *  2) التبديل بين 5 أقسام (تلفزيون / مكيف / رسيفر / باب ذكي / إضاءة) عبر TabLayout.
 *  3) عند الضغط على أي زر: أخذ الكود Hex المناسب من IrCodesRepository، تحويله
 *     إلى نمط نبضات عبر IrEncoder، ثم إرساله فعلياً عبر ConsumerIrManager.transmit().
 *
 * ⚠️ ملاحظة تقنية مهمة جداً:
 * واجهة Android الرسمية (ConsumerIrManager) تدعم "الإرسال فقط" (Transmit-Only).
 * لا يوجد أي API رسمي من جوجل لاستقبال أو "تعلّم" إشارات IR قادمة من ريموت آخر.
 * لذلك ميزة "التقاط كود من الباب الذكي الأصلي" غير ممكنة عبر هذه المكتبة، وما
 * نوفره هو حقل إدخال يدوي للكود إن كان موثقاً من الشركة المصنعة للباب.
 * =====================================================================================
 */
public class MainActivity extends AppCompatActivity {

    private ConsumerIrManager irManager;

    // مراجع لكل مخطط (Layout) داخل الـ XML لتبديل الظهور بينها حسب التبويب المختار
    private LinearLayout layoutTv, layoutAc, layoutReceiver, layoutDoor, layoutLed;

    // متغيرات حالة المكيف الحالية (تُستخدم لبناء حزمة الإرسال الكاملة في كل مرة)
    private int currentAcTemp = 24;
    private int currentAcMode = 1;   // 1 = Cool افتراضياً
    private int currentAcFan = 2;    // سرعة متوسطة افتراضياً
    private boolean acPowerState = false;

    // الماركة المختارة حالياً لكل قسم (TV / AC)
    private String selectedTvBrand = "Samsung";
    private String selectedAcBrand = "Gree";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // تهيئة مدير الأشعة تحت الحمراء من النظام
        irManager = (ConsumerIrManager) getSystemService(CONSUMER_IR_SERVICE);

        // التحقق من دعم الجهاز لباعث IR فعلياً قبل أي محاولة إرسال
        if (irManager == null || !irManager.hasIrEmitter()) {
            Toast.makeText(this,
                    "هذا الجهاز لا يحتوي على باعث IR فعلي، لن يعمل الريموت.",
                    Toast.LENGTH_LONG).show();
        }

        bindViews();
        setupTabs();
        setupSpinners();
        setupTvButtons();
        setupAcButtons();
        setupReceiverButtons();
        setupDoorButtons();
        setupLedButtons();
    }

    /** ربط كل مخططات الأقسام الخمسة بمتغيراتها */
    private void bindViews() {
        layoutTv = findViewById(R.id.layoutTv);
        layoutAc = findViewById(R.id.layoutAc);
        layoutReceiver = findViewById(R.id.layoutReceiver);
        layoutDoor = findViewById(R.id.layoutDoor);
        layoutLed = findViewById(R.id.layoutLed);
    }

    /** إعداد التبويبات العلوية والتبديل بين الأقسام عند اختيار أي منها */
    private void setupTabs() {
        TabLayout tabLayout = findViewById(R.id.tabLayout);
        tabLayout.addTab(tabLayout.newTab().setText("تلفزيون"));
        tabLayout.addTab(tabLayout.newTab().setText("مكيف"));
        tabLayout.addTab(tabLayout.newTab().setText("رسيفر"));
        tabLayout.addTab(tabLayout.newTab().setText("باب ذكي"));
        tabLayout.addTab(tabLayout.newTab().setText("إضاءة LED"));

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                showOnly(tab.getPosition());
            }
            @Override public void onTabUnselected(TabLayout.Tab tab) {}
            @Override public void onTabReselected(TabLayout.Tab tab) {}
        });
    }

    /** إخفاء كل الأقسام وإظهار القسم المطلوب فقط حسب رقم التبويب */
    private void showOnly(int position) {
        layoutTv.setVisibility(position == 0 ? LinearLayout.VISIBLE : LinearLayout.GONE);
        layoutAc.setVisibility(position == 1 ? LinearLayout.VISIBLE : LinearLayout.GONE);
        layoutReceiver.setVisibility(position == 2 ? LinearLayout.VISIBLE : LinearLayout.GONE);
        layoutDoor.setVisibility(position == 3 ? LinearLayout.VISIBLE : LinearLayout.GONE);
        layoutLed.setVisibility(position == 4 ? LinearLayout.VISIBLE : LinearLayout.GONE);
    }

    /** تعبئة القوائم المنسدلة (الماركات، وضع التكييف، سرعة المروحة) */
    private void setupSpinners() {
        Spinner spinnerTvBrand = findViewById(R.id.spinnerTvBrand);
        ArrayAdapter<String> tvAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"Samsung", "LG", "Sony", "TCL"});
        spinnerTvBrand.setAdapter(tvAdapter);
        spinnerTvBrand.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, android.view.View view, int position, long id) {
                selectedTvBrand = parent.getItemAtPosition(position).toString();
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });

        Spinner spinnerAcBrand = findViewById(R.id.spinnerAcBrand);
        ArrayAdapter<String> acAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"Gree", "LG", "O General"});
        spinnerAcBrand.setAdapter(acAdapter);
        spinnerAcBrand.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, android.view.View view, int position, long id) {
                selectedAcBrand = parent.getItemAtPosition(position).toString();
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });

        Spinner spinnerAcMode = findViewById(R.id.spinnerAcMode);
        spinnerAcMode.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"Auto", "Cool", "Dry", "Fan", "Heat"}));
        spinnerAcMode.setSelection(1); // Cool افتراضياً
        spinnerAcMode.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, android.view.View view, int position, long id) {
                currentAcMode = position;
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });

        Spinner spinnerAcFan = findViewById(R.id.spinnerAcFan);
        spinnerAcFan.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"منخفضة", "متوسطة", "عالية", "تلقائي"}));
        spinnerAcFan.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, android.view.View view, int position, long id) {
                currentAcFan = position;
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });
    }

    // ===================================================================================
    // قسم التلفزيون: يقرأ خريطة أكواد الماركة المختارة، ثم يرسل الزر المطلوب
    // ===================================================================================
    private void setupTvButtons() {
        findViewById(R.id.btnTvPower).setOnClickListener(v -> sendTvButton("POWER"));
        findViewById(R.id.btnTvVolUp).setOnClickListener(v -> sendTvButton("VOL_UP"));
        findViewById(R.id.btnTvVolDown).setOnClickListener(v -> sendTvButton("VOL_DOWN"));
        findViewById(R.id.btnTvMute).setOnClickListener(v -> sendTvButton("MUTE"));
        findViewById(R.id.btnTvChUp).setOnClickListener(v -> sendTvButton("CH_UP"));
        findViewById(R.id.btnTvChDown).setOnClickListener(v -> sendTvButton("CH_DOWN"));
        findViewById(R.id.btnTvSource).setOnClickListener(v -> sendTvButton("SOURCE"));
        findViewById(R.id.btnTvMenu).setOnClickListener(v -> sendTvButton("MENU"));
        findViewById(R.id.btnTvHome).setOnClickListener(v -> sendTvButton("HOME"));
    }

    private void sendTvButton(String key) {
        Map<String, IrCodesRepository.IrButton> codes;
        switch (selectedTvBrand) {
            case "LG":   codes = IrCodesRepository.getLgTvCodes(); break;
            case "Sony": codes = IrCodesRepository.getSonyTvCodes(); break;
            case "TCL":  codes = IrCodesRepository.getTclTvCodes(); break;
            default:     codes = IrCodesRepository.getSamsungTvCodes(); break;
        }
        IrCodesRepository.IrButton button = codes.get(key);
        if (button != null) {
            transmit(IrEncoder.encodeButton(button), 38000); // تردد الحامل القياسي 38kHz
        }
    }

    // ===================================================================================
    // قسم المكيف: يبني حزمة الحالة الكاملة (حرارة + وضع + مروحة + طاقة) ثم يرسلها
    // ===================================================================================
    private void setupAcButtons() {
        androidx.appcompat.widget.AppCompatTextView tvTemp = findViewById(R.id.tvAcTemp);

        findViewById(R.id.btnAcTempUp).setOnClickListener(v -> {
            if (currentAcTemp < 30) currentAcTemp++;
            tvTemp.setText(currentAcTemp + "°C");
            sendAcState();
        });

        findViewById(R.id.btnAcTempDown).setOnClickListener(v -> {
            if (currentAcTemp > 16) currentAcTemp--;
            tvTemp.setText(currentAcTemp + "°C");
            sendAcState();
        });

        findViewById(R.id.btnAcPower).setOnClickListener(v -> {
            acPowerState = !acPowerState;
            sendAcState();
        });
    }

    private void sendAcState() {
        // ملاحظة: حالياً نستخدم بنية Gree لكل الماركات كنموذج توضيحي موحّد.
        // لضبط دقيق 100% لكل ماركة (LG أو O General) يُنصح بمطابقة بنية البايتات
        // الخاصة بكل بروتوكول رسمي (تختلف ترتيب البتات والـ Checksum بينها).
        int[] pattern = IrEncoder.buildGreeAcState(currentAcTemp, currentAcMode, currentAcFan, acPowerState);
        transmit(pattern, 38000);
    }

    // ===================================================================================
    // قسم الرسيفر
    // ===================================================================================
    private void setupReceiverButtons() {
        Map<String, IrCodesRepository.IrButton> codes = IrCodesRepository.getReceiverCodes();

        findViewById(R.id.btnRecPower).setOnClickListener(v -> transmit(IrEncoder.encodeButton(codes.get("POWER")), 38000));
        findViewById(R.id.btnRecChUp).setOnClickListener(v -> transmit(IrEncoder.encodeButton(codes.get("CH_UP")), 38000));
        findViewById(R.id.btnRecChDown).setOnClickListener(v -> transmit(IrEncoder.encodeButton(codes.get("CH_DOWN")), 38000));
        findViewById(R.id.btnRecOk).setOnClickListener(v -> transmit(IrEncoder.encodeButton(codes.get("OK")), 38000));
        findViewById(R.id.btnRecMenu).setOnClickListener(v -> transmit(IrEncoder.encodeButton(codes.get("MENU")), 38000));
        findViewById(R.id.btnRecExit).setOnClickListener(v -> transmit(IrEncoder.encodeButton(codes.get("EXIT")), 38000));
    }

    // ===================================================================================
    // قسم الباب الذكي: يعتمد على كود يدخله المستخدم لأن لا يوجد بروتوكول IR موحّد
    // ===================================================================================
    private void setupDoorButtons() {
        EditText etCode = findViewById(R.id.etDoorCustomCode);

        findViewById(R.id.btnDoorOpen).setOnClickListener(v -> sendDoorCustomCode(etCode));
        findViewById(R.id.btnDoorClose).setOnClickListener(v -> sendDoorCustomCode(etCode));
    }

    private void sendDoorCustomCode(EditText etCode) {
        String text = etCode.getText().toString().trim();
        if (text.isEmpty()) {
            Toast.makeText(this, "الرجاء إدخال كود IR الخاص بالباب أولاً", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            // يقبل صيغة "0x...." أو رقم عادي
            long code = text.toLowerCase().startsWith("0x")
                    ? Long.parseLong(text.substring(2), 16)
                    : Long.parseLong(text, 16);
            transmit(IrEncoder.encodeNec(code, 32), 38000);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "صيغة الكود غير صحيحة", Toast.LENGTH_SHORT).show();
        }
    }

    // ===================================================================================
    // قسم إضاءة LED
    // ===================================================================================
    private void setupLedButtons() {
        Map<String, IrCodesRepository.IrButton> codes = IrCodesRepository.getLedLightCodes();

        findViewById(R.id.btnLedPower).setOnClickListener(v -> transmit(IrEncoder.encodeButton(codes.get("POWER_ON")), 38000));
        findViewById(R.id.btnLedRed).setOnClickListener(v -> transmit(IrEncoder.encodeButton(codes.get("RED")), 38000));
        findViewById(R.id.btnLedGreen).setOnClickListener(v -> transmit(IrEncoder.encodeButton(codes.get("GREEN")), 38000));
        findViewById(R.id.btnLedBlue).setOnClickListener(v -> transmit(IrEncoder.encodeButton(codes.get("BLUE")), 38000));
        findViewById(R.id.btnLedWhite).setOnClickListener(v -> transmit(IrEncoder.encodeButton(codes.get("WHITE")), 38000));
        findViewById(R.id.btnLedBrightUp).setOnClickListener(v -> transmit(IrEncoder.encodeButton(codes.get("BRIGHT_UP")), 38000));
        findViewById(R.id.btnLedBrightDown).setOnClickListener(v -> transmit(IrEncoder.encodeButton(codes.get("BRIGHT_DN")), 38000));
        findViewById(R.id.btnLedFlash).setOnClickListener(v -> transmit(IrEncoder.encodeButton(codes.get("FLASH")), 38000));
    }

    /**
     * الدالة المركزية التي تُرسل النمط فعلياً عبر باعث IR.
     * @param pattern مصفوفة أطوال النبضات/الفراغات بالميكروثانية
     * @param frequencyHz تردد الموجة الحاملة (38000 هو المعيار الأشيع في 90% من الأجهزة)
     */
    private void transmit(int[] pattern, int frequencyHz) {
        if (irManager == null || !irManager.hasIrEmitter()) {
            Toast.makeText(this, "لا يوجد باعث IR على هذا الجهاز", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            irManager.transmit(frequencyHz, pattern);
        } catch (Exception e) {
            Toast.makeText(this, "فشل الإرسال: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}
