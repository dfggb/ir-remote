package com.example.irremote;

import java.util.HashMap;
import java.util.Map;

/**
 * =====================================================================================
 *  IrCodesRepository
 * =====================================================================================
 * هذا الملف يحتوي على "أكواد الأزرار" (Hex Codes) الحقيقية والمنشورة علنياً للأجهزة
 * الأكثر شيوعاً. هذه الأكواد تُستخدم مع بروتوكولات معروفة (NEC أو SIRC) لتوليد
 * نمط النبضات (Pulse Pattern) الذي يفهمه ConsumerIrManager.
 *
 * ملاحظات هامة جداً يجب معرفتها:
 * 1) أجهزة التلفزيون والرسيفرات تستخدم غالباً بروتوكول NEC (32-bit) أو SIRC (سوني).
 *    هذه الأكواد شبه موحدة لكل ماركة ولذلك يمكن نشرها كجدول ثابت.
 * 2) أجهزة التكييف (Gree, LG, OGeneral) لا تعمل بنظام "زر واحد = كود ثابت"، بل ترسل
 *    "حزمة حالة كاملة" (State Packet) تحتوي الحرارة + الوضع + سرعة المروحة معاً في
 *    كل ضغطة، وقد يختلف طول الحزمة بين موديل وآخر لنفس الشركة. لهذا السبب أضفنا لها
 *    دالة بناء (Builder) بدل جدول ثابت، وهي الطريقة المعتمدة في مكتبات مفتوحة المصدر
 *    مشهورة مثل IRremoteESP8266. إن لم تُطابق حرارة أو موديل مكيفك تماماً، يفضّل
 *    التحقق بجهاز التقاط IR حقيقي، لأن Android للأسف لا يدعم الاستقبال (راجع الشرح
 *    في MainActivity).
 * 3) أكواد اللمبات الذكية (RGB LED) المرفقة هنا تخص "الريموت الشائع ذو 44 زر" الذي
 *    يأتي مع أغلب شرائط LED الصينية المنتشرة، وهو نمط موحّد تقريباً عالمياً.
 * 4) "الأبواب الذكية" لا تملك بروتوكول IR موحّد بين الشركات المصنعة (أغلبها أصلاً
 *    يعمل بـ RF أو WiFi/Bluetooth وليس IR). لذلك أدرجنا دالة عامة لإرسال كود مخصص
 *    (Custom Hex) يمكن للمستخدم إدخاله يدوياً إن كان باب مصنّعه يوثّق كود IR الخاص به.
 * =====================================================================================
 */
public class IrCodesRepository {

    // بروتوكولات مدعومة
    public static final int PROTOCOL_NEC = 1;
    public static final int PROTOCOL_SIRC = 2;

    /** عنصر يمثل زراً واحداً: القيمة الست عشرية + البروتوكول المستخدم لفكّها */
    public static class IrButton {
        public final long hexCode;
        public final int protocol;
        public final int bits; // عدد البتات (32 لـ NEC القياسي، 12/15/20 لـ SIRC)

        public IrButton(long hexCode, int protocol, int bits) {
            this.hexCode = hexCode;
            this.protocol = protocol;
            this.bits = bits;
        }
    }

    // =================================================================================
    // 1) أكواد شاشات التلفزيون (TVs) - بروتوكول NEC ما لم يُذكر غير ذلك
    // =================================================================================

    public static Map<String, IrButton> getSamsungTvCodes() {
        Map<String, IrButton> m = new HashMap<>();
        // عنوان جهاز Samsung القياسي هو 0x07 مكرر (0xE0E0) في NEC الموسّع
        m.put("POWER",     new IrButton(0xE0E040BFL, PROTOCOL_NEC, 32));
        m.put("VOL_UP",    new IrButton(0xE0E0E01FL, PROTOCOL_NEC, 32));
        m.put("VOL_DOWN",  new IrButton(0xE0E0D02FL, PROTOCOL_NEC, 32));
        m.put("MUTE",      new IrButton(0xE0E0F00FL, PROTOCOL_NEC, 32));
        m.put("CH_UP",     new IrButton(0xE0E048B7L, PROTOCOL_NEC, 32));
        m.put("CH_DOWN",   new IrButton(0xE0E008F7L, PROTOCOL_NEC, 32));
        m.put("SOURCE",    new IrButton(0xE0E0807FL, PROTOCOL_NEC, 32));
        m.put("MENU",      new IrButton(0xE0E058A7L, PROTOCOL_NEC, 32));
        m.put("HOME",      new IrButton(0xE0E09E61L, PROTOCOL_NEC, 32));
        m.put("BACK",      new IrButton(0xE0E01AE5L, PROTOCOL_NEC, 32));
        return m;
    }

    public static Map<String, IrButton> getLgTvCodes() {
        Map<String, IrButton> m = new HashMap<>();
        // عنوان جهاز LG القياسي هو 0x20DF
        m.put("POWER",     new IrButton(0x20DF10EFL, PROTOCOL_NEC, 32));
        m.put("VOL_UP",    new IrButton(0x20DF40BFL, PROTOCOL_NEC, 32));
        m.put("VOL_DOWN",  new IrButton(0x20DFC03FL, PROTOCOL_NEC, 32));
        m.put("MUTE",      new IrButton(0x20DF906FL, PROTOCOL_NEC, 32));
        m.put("CH_UP",     new IrButton(0x20DF00FFL, PROTOCOL_NEC, 32));
        m.put("CH_DOWN",   new IrButton(0x20DF807FL, PROTOCOL_NEC, 32));
        m.put("SOURCE",    new IrButton(0x20DFD02FL, PROTOCOL_NEC, 32));
        m.put("MENU",      new IrButton(0x20DF43BCL, PROTOCOL_NEC, 32));
        m.put("HOME",      new IrButton(0x20DF3EC1L, PROTOCOL_NEC, 32));
        m.put("BACK",      new IrButton(0x20DF14EBL, PROTOCOL_NEC, 32));
        return m;
    }

    public static Map<String, IrButton> getSonyTvCodes() {
        // سوني تستخدم بروتوكول SIRC (12 بت) وليس NEC
        Map<String, IrButton> m = new HashMap<>();
        m.put("POWER",     new IrButton(0xA90L, PROTOCOL_SIRC, 12));
        m.put("VOL_UP",    new IrButton(0x490L, PROTOCOL_SIRC, 12));
        m.put("VOL_DOWN",  new IrButton(0xC90L, PROTOCOL_SIRC, 12));
        m.put("MUTE",      new IrButton(0x290L, PROTOCOL_SIRC, 12));
        m.put("CH_UP",     new IrButton(0x090L, PROTOCOL_SIRC, 12));
        m.put("CH_DOWN",   new IrButton(0x890L, PROTOCOL_SIRC, 12));
        m.put("SOURCE",    new IrButton(0xA5CL, PROTOCOL_SIRC, 12));
        m.put("MENU",      new IrButton(0x070L, PROTOCOL_SIRC, 12));
        m.put("HOME",      new IrButton(0x2F0L, PROTOCOL_SIRC, 12));
        m.put("BACK",      new IrButton(0xC38L, PROTOCOL_SIRC, 15));
        return m;
    }

    public static Map<String, IrButton> getTclTvCodes() {
        // أغلب أجهزة TCL (وشاشات صينية أخرى تبنى على نفس المنصة) تستخدم NEC بعنوان 0x00
        Map<String, IrButton> m = new HashMap<>();
        m.put("POWER",     new IrButton(0x00FF12EDL, PROTOCOL_NEC, 32));
        m.put("VOL_UP",    new IrButton(0x00FF40BFL, PROTOCOL_NEC, 32));
        m.put("VOL_DOWN",  new IrButton(0x00FFC03FL, PROTOCOL_NEC, 32));
        m.put("MUTE",      new IrButton(0x00FF906FL, PROTOCOL_NEC, 32));
        m.put("CH_UP",     new IrButton(0x00FF00FFL, PROTOCOL_NEC, 32));
        m.put("CH_DOWN",   new IrButton(0x00FF807FL, PROTOCOL_NEC, 32));
        m.put("SOURCE",    new IrButton(0x00FF9867L, PROTOCOL_NEC, 32));
        m.put("MENU",      new IrButton(0x00FF22DDL, PROTOCOL_NEC, 32));
        m.put("HOME",      new IrButton(0x00FF32CDL, PROTOCOL_NEC, 32));
        m.put("BACK",      new IrButton(0x00FF52ADL, PROTOCOL_NEC, 32));
        return m;
    }

    // =================================================================================
    // 2) أكواد الرسيفرات / سيرفرات القنوات (Receivers / Set-top Boxes)
    //    أغلب الرسيفرات العربية (Echolink, Dreambox, Starsat...) تعتمد على NEC
    //    بعنوان 0x00 أو 0x40 تقريباً موحّد بين معظم الشركات المستنسخة من نفس المرجع
    // =================================================================================
    public static Map<String, IrButton> getReceiverCodes() {
        Map<String, IrButton> m = new HashMap<>();
        m.put("POWER",     new IrButton(0x00FF827DL, PROTOCOL_NEC, 32));
        m.put("VOL_UP",    new IrButton(0x00FFA05FL, PROTOCOL_NEC, 32));
        m.put("VOL_DOWN",  new IrButton(0x00FF10EFL, PROTOCOL_NEC, 32));
        m.put("MUTE",      new IrButton(0x00FF906FL, PROTOCOL_NEC, 32));
        m.put("CH_UP",     new IrButton(0x00FF906FL, PROTOCOL_NEC, 32));
        m.put("CH_DOWN",   new IrButton(0x00FFB04FL, PROTOCOL_NEC, 32));
        m.put("OK",        new IrButton(0x00FF38C7L, PROTOCOL_NEC, 32));
        m.put("MENU",      new IrButton(0x00FF9867L, PROTOCOL_NEC, 32));
        m.put("EXIT",      new IrButton(0x00FFE21DL, PROTOCOL_NEC, 32));
        return m;
    }

    // =================================================================================
    // 3) أكواد لمبات LED الذكية (ريموت "44 زر" الشائع عالمياً مع شرائط RGB)
    //    البروتوكول NEC بعنوان 0x00
    // =================================================================================
    public static Map<String, IrButton> getLedLightCodes() {
        Map<String, IrButton> m = new HashMap<>();
        m.put("POWER_ON",  new IrButton(0x00FFF00FL, PROTOCOL_NEC, 32));
        m.put("POWER_OFF", new IrButton(0x00FFF00FL, PROTOCOL_NEC, 32)); // نفس زر التبديل غالباً
        m.put("BRIGHT_UP", new IrButton(0x00FF58A7L, PROTOCOL_NEC, 32));
        m.put("BRIGHT_DN", new IrButton(0x00FFD827L, PROTOCOL_NEC, 32));
        m.put("RED",       new IrButton(0x00FF906FL, PROTOCOL_NEC, 32));
        m.put("GREEN",     new IrButton(0x00FF6897L, PROTOCOL_NEC, 32));
        m.put("BLUE",      new IrButton(0x00FFB04FL, PROTOCOL_NEC, 32));
        m.put("WHITE",     new IrButton(0x00FFF807L, PROTOCOL_NEC, 32));
        m.put("FLASH",     new IrButton(0x00FFD02FL, PROTOCOL_NEC, 32));
        m.put("STROBE",    new IrButton(0x00FFF00FL, PROTOCOL_NEC, 32));
        m.put("FADE",      new IrButton(0x00FF00FFL, PROTOCOL_NEC, 32));
        m.put("SMOOTH",    new IrButton(0x00FF807FL, PROTOCOL_NEC, 32));
        return m;
    }
}
