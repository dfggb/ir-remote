package com.example.irremote;

import java.util.ArrayList;
import java.util.List;

/**
 * =====================================================================================
 *  IrEncoder
 * =====================================================================================
 * ConsumerIrManager لا يقبل "كود Hex" مباشرة، بل يطلب مصفوفة int[] تمثل أطوال
 * النبضات والفراغات بالميكروثانية (pattern[0]=نبضة تشغيل، pattern[1]=فراغ، ...).
 * لذلك هذا الملف يحوّل الأكواد Hex الموجودة في IrCodesRepository إلى هذا النمط،
 * حسب بروتوكول كل جهاز (NEC أو SIRC)، ويحتوي أيضاً على "باني" حزمة تكييف Gree
 * كمثال عملي على بروتوكولات التكييف المعقّدة.
 * =====================================================================================
 */
public class IrEncoder {

    // ---------------------------------------------------------------------------------
    // بروتوكول NEC: الأكثر انتشاراً في تلفزيونات ورسيفرات ولمبات LED
    // - نبضة بداية 9000us + فراغ 4500us
    // - كل بت: نبضة 562us ثم فراغ (562us لـ 0 أو 1690us لـ 1)
    // - نبضة إنهاء 562us
    // ---------------------------------------------------------------------------------
    public static int[] encodeNec(long hexCode, int bits) {
        List<Integer> pattern = new ArrayList<>();

        pattern.add(9000); // Header pulse (نبضة البداية)
        pattern.add(4500); // Header space (الفراغ بعد البداية)

        // إرسال البتات من الأعلى إلى الأدنى (MSB أولاً) - وهو الشائع في NEC للأكواد الجاهزة
        for (int i = bits - 1; i >= 0; i--) {
            boolean isOne = ((hexCode >> i) & 1) == 1;
            pattern.add(562);              // نبضة البت (ثابتة دائماً)
            pattern.add(isOne ? 1690 : 562); // الفراغ يحدد إن كان البت 1 أو 0
        }

        pattern.add(562); // نبضة الإنهاء (Trailer)

        return toIntArray(pattern);
    }

    // ---------------------------------------------------------------------------------
    // بروتوكول SIRC (سوني):
    // - نبضة بداية 2400us + فراغ 600us
    // - البت 1: نبضة 1200us / البت 0: نبضة 600us، والفراغ ثابت 600us دائماً
    // - يُرسل LSB أولاً (الأقل أهمية أولاً)
    // - يفضَّل تكرار الإرسال 3 مرات لضمان الاستقبال (سوني تتطلب ذلك غالباً)
    // ---------------------------------------------------------------------------------
    public static int[] encodeSirc(long hexCode, int bits) {
        List<Integer> pattern = new ArrayList<>();

        pattern.add(2400); // Header pulse
        pattern.add(600);  // Header space

        for (int i = 0; i < bits; i++) {
            boolean isOne = ((hexCode >> i) & 1) == 1;
            pattern.add(isOne ? 1200 : 600); // طول النبضة يحدد البت
            pattern.add(600);                // الفراغ ثابت دائماً
        }

        return toIntArray(pattern);
    }

    /** دالة موحّدة: تختار الترميز المناسب حسب بروتوكول الزر */
    public static int[] encodeButton(IrCodesRepository.IrButton button) {
        if (button.protocol == IrCodesRepository.PROTOCOL_SIRC) {
            return encodeSirc(button.hexCode, button.bits);
        }
        return encodeNec(button.hexCode, button.bits);
    }

    private static int[] toIntArray(List<Integer> list) {
        int[] arr = new int[list.size()];
        for (int i = 0; i < arr.length; i++) arr[i] = list.get(i);
        return arr;
    }

    // ===================================================================================
    //  مكيفات الهواء (Air Conditioners) - بروتوكول Gree كمثال (35 بايت / 280 بت تقريباً)
    // ===================================================================================
    // مكيفات Gree/LG/OGeneral لا ترسل "زر" بل ترسل "حالة كاملة" (حرارة + وضع + مروحة)
    // في كل ضغطة. البنية أدناه مبسّطة وتتبع المنطق العام المستخدم في مكتبات مفتوحة
    // المصدر مرجعية (مثل IRremoteESP8266) لبروتوكول Gree، وهي:
    //   Byte0: bits0-3 = Mode (0=Auto,1=Cool,2=Dry,3=Fan,4=Heat) | bits4-7=Fan speed<<4
    //   Byte1: bits0-3 = Temperature (Temp - 16)  | bit4 = Timer flag
    //   Byte2: ثابت غالباً (0x50 أو حسب الموديل)
    //   Byte3: bit3 = Power ON/OFF
    //   ... آخر بايت = Checksum بسيط (XOR أو جمع حسب الموديل)
    //
    // بسبب اختلاف تفاصيل الـ Checksum بين موديلات Gree نفسها، هذه الدالة توفر البنية
    // العامة القابلة للتوسعة، وننصح بضبطها على جهاز حقيقي إذا لم يستجب المكيّف.
    // ===================================================================================
    public static int[] buildGreeAcState(int temperatureCelsius, int mode, int fanSpeed, boolean powerOn) {
        byte[] state = new byte[8]; // بعض موديلات Gree تستخدم 4 بايت وبعضها 8 بايت

        int tempOffset = Math.max(16, Math.min(30, temperatureCelsius)) - 16; // المدى المسموح 16-30°
        state[0] = (byte) ((mode & 0x0F) | ((fanSpeed & 0x03) << 4));
        state[1] = (byte) (tempOffset & 0x0F);
        state[2] = (byte) 0x50; // قيمة ثابتة شائعة في عائلة Gree
        state[3] = (byte) (powerOn ? 0x08 : 0x00);

        // Checksum بسيط: XOR لكل البايتات السابقة (تقريب شائع، وقد يختلف فعلياً حسب الموديل)
        byte checksum = 0;
        for (int i = 0; i < 7; i++) checksum ^= state[i];
        state[7] = checksum;

        // تحويل البايتات إلى بت ستريم ثم ترميزها بنمط NEC-like المستخدم في Gree
        List<Integer> pattern = new ArrayList<>();
        pattern.add(9000);
        pattern.add(4500);
        for (byte b : state) {
            for (int bit = 0; bit < 8; bit++) {
                boolean isOne = ((b >> bit) & 1) == 1; // Gree يرسل LSB أولاً لكل بايت
                pattern.add(650);
                pattern.add(isOne ? 1600 : 550);
            }
        }
        pattern.add(650);

        return toIntArray(pattern);
    }
}
